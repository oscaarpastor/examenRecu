export class Factura {
    constructor(id, idFra, Fecha, idCliente, Importe) {
        this.id = id;
        this.idFra = idFra;
        this.Fecha = Fecha;
        this.idCliente = idCliente;
        this.Importe = Importe;
    }

    getId() {
        return this.id;
    }

    getIdFra() {
        return this.idFra;
    }

    getFecha() {
        return this.Fecha;
    }

    getIdCliente() {
        return this.idCliente;
    }

    getImporte() {
        return this.Importe;
    }
}
