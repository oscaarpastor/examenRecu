export class users {
    constructor(id, first_name, last_name, user_name, email, pwd, r_pwd) {
        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.user_name = user_name;
        this.email = email;
        this.pwd = pwd;
        this.r_pwd = r_pwd;
    }
  
    getid() {
      return this.id;
    }
  
    getfirst_name() {
        return this.first_name;
    }
    getlast_name() {
        return this.last_name;
    }
    getuser_name(){
        return this.user_name
    }
    getemail(){
        return this.email
    }
    getpwd(){
        return this.pwd
    }
    getr_pwd(){
        return this.r_pwd
    }

  }
  