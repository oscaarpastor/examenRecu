export class Cliente {
  constructor(id, title, firstname, lastname, email, phone, password, id_pais,pais) {
      this.id = id;
      this.genero = title;
      this.fname = firstname;
      this.lname = lastname;
      this.email = email;
      this.phone = phone;
      this.password = password;
      this.id_pais = id_pais;
      this.pais = pais;
  }

  getId() {
    return this.id;
  }

  getTitle() {
      return this.genero;
  }
  getFirstName() {
      return this.fname;
  }
  getLastName() {
      return this.lname;
  }
  getEmail() {
      return this.email;
  }
  getPhone() {
      return this.phone;
  }
  getPassword() {
      return this.password;
  }
  getId_pais() {
      return this.id_pais;
  }
  get_pais() {
    return this.pais;
  }
}
