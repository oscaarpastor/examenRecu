export class Pais {
  constructor(id, country) {
      this.id = id;     
      this.Nombre = country;
  }

  getId() {
    return this.id;
  }
 
  getPais() {
      return this.Nombre;
  }
}
