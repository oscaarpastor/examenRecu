export class Alumnos {
    constructor(idAlumno, alumno, puntuacion) {
        this.idAlumno = idAlumno;
        this.alumno = alumno;
        this.puntuacion = puntuacion;
    }
  
    getIdAlumno() {
      return this.idAlumno;
    }
  
    getAlumno() {
        return this.alumno;
    }
    getPuntuacion() {
        return this.puntuacion;
    }
  }
  