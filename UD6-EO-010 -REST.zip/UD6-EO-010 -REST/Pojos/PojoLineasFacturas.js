export class LineaFactura {
  constructor(id, idFra, cantidad, Descripcion, Precio, Foto, idProducto) {
      this.id = id;     
      this.idFra = idFra;
      this.cantidad = cantidad;
      this.Descripcion = Descripcion;
      this.Precio = Precio;
      this.Foto = Foto;
      this.idProducto = idProducto;
  }

  getId() {
    return this.id;
  }

  getIdFra() {
    return this.idFra;
  }

  getCantidad() {
    return this.cantidad;
  }
 
  getDescripcion() {
    return this.Descripcion;
  }

  getPrecio() {
      return this.Precio;
  }

  getFoto() {
    return this.Foto
  }

  getIdProducto() {
    return this.idProducto
  }
}
