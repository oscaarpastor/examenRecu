export class Productos {
    constructor(id, Nombre, Foto, Precio) {
        this.id = id;
        this.Nombre = Nombre;
        this.Foto = Foto;
        this.Precio = Precio;
    }
  
    getId() {
      return this.id;
    }
  
    getNombre() {
        return this.Nombre;
    }

    getFoto() {
        return this.Foto;
    }

    getPrecio() {
        return this.Precio;
    }

  }
  