import { Factura } from '../Pojos/PojoFacturas.js';

export class DatosVistaFacturas {
    constructor() {
        this.arrayFacturas = [];
        this.cargarFacturas();
    }

    async cargarFacturas() {
        try {
            const response = await fetch("./PostBackend/api.php/Facturas", {
                method: "GET",
                headers: {
                    "Content-type": "application/json",
                },
            });

            const data = await response.json();

            // Verifica que la respuesta contiene las facturas
            const facturasRecords = data.Facturas.records;

            // Pasa los datos a objetos Factura
            facturasRecords.forEach((item) => {
                const factura = new Factura(item[0], item[1], item[2], item[3], item[4]);
                this.arrayFacturas.push(factura);
            });
        } catch (error) {
            console.error("Error al cargar facturas:", error);
        }
    }

    getFacturas() {
        return this.arrayFacturas;
    }
}
