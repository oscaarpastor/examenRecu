import { DatosVistaFacturas } from "./mVistaFacturas.js";

class CtrlVistaFacturas {
    constructor() {
        this.vistaFacturas = document.getElementById("VistaFacturas");
        this.tablaFacturas = document.getElementById("TablaFacturas");
        this.formularioFactura = document.getElementById("formularioFactura");

        this.datosVistaFacturas = new DatosVistaFacturas();

        // Eventos
        document.getElementById("btnAbrirFormularioFactura").addEventListener("click", () => this.toggleFormularioFactura());
        document.getElementById("btnGuardarFactura").addEventListener("click", () => this.guardarFactura());
        document.getElementById("btnCancelarFactura").addEventListener("click", () => this.cancelarFormulario());

        // Espera un segundo para cargar los datos y actualizar la tabla
        setTimeout(() => this.generarTablaFacturas(), 1000);
    }

    // Mostrar u ocultar el formulario
    toggleFormularioFactura() {
        // Limpiar el formulario al abrirlo
        this.resetFormulario();
        if (this.formularioFactura.style.display === "block") {
            this.formularioFactura.style.display = "none";
        } else {
            this.formularioFactura.style.display = "block";
        }
    }

    // Función para generar la tabla de facturas
    generarTablaFacturas() {
        const facturas = this.datosVistaFacturas.getFacturas();
        this.tablaFacturas.innerHTML = ""; // Limpiar contenido previo

        if (facturas.length > 0) {
            let tablaHTML = `
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ID Factura</th>
                            <th>Fecha</th>
                            <th>ID Cliente</th>
                            <th>Importe</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            facturas.forEach((factura) => {
                tablaHTML += `
                    <tr>
                        <td>${factura.getId()}</td>
                        <td>${factura.getIdFra()}</td>
                        <td>${factura.getFecha()}</td>
                        <td>${factura.getIdCliente()}</td>
                        <td>${factura.getImporte()} €</td>
                        <td>
                            <button class="btnEditar" data-id="${factura.getId()}">Editar</button>
                            <button class="btnEliminar" data-id="${factura.getId()}">Eliminar</button>
                        </td>
                    </tr>
                `;
            });

            tablaHTML += `
                    </tbody>
                </table>
            `;
            this.tablaFacturas.innerHTML = tablaHTML;

            // Añadir eventos a los botones de editar y eliminar
            document.querySelectorAll(".btnEditar").forEach((btn) => {
                btn.addEventListener("click", (event) => this.editarFactura(event));
            });

            document.querySelectorAll(".btnEliminar").forEach((btn) => {
                btn.addEventListener("click", (event) => this.eliminarFactura(event));
            });
        } else {
            this.tablaFacturas.innerHTML = "<p>No hay facturas disponibles.</p>";
        }
    }

    // Función para eliminar una factura
    async eliminarFactura(event) {
        const idFactura = event.target.getAttribute("data-id");

        if (confirm("¿Estás seguro de que quieres eliminar esta factura?")) {
            try {
                const response = await fetch(`./PostBackend/api.php/Facturas/${idFactura}`, {
                    method: "DELETE",
                });

                if (response.ok) {
                    alert("Factura eliminada correctamente.");
                    this.datosVistaFacturas.arrayFacturas = this.datosVistaFacturas.arrayFacturas.filter(
                        (factura) => factura.getId() !== idFactura
                    );
                    this.generarTablaFacturas(); // Actualizar la tabla
                } else {
                    alert("Error al eliminar la factura.");
                }
            } catch (error) {
                console.error("Error al eliminar factura:", error);
                alert("Error al eliminar factura.");
            }
        }
    }

    // Función para guardar una nueva factura
    async guardarFactura() {
        const idFra = document.getElementById("idFra").value;
        const Fecha = document.getElementById("Fecha").value;
        const idCliente = document.getElementById("idCliente").value;
        const Importe = parseFloat(document.getElementById("Importe").value);

        if (!idFra || !Fecha || !idCliente || isNaN(Importe)) {
            alert("Todos los campos son obligatorios y el campo 'Importe' debe ser un número válido.");
            return;
        }

        const nuevaFactura = {
            idFra: idFra,
            Fecha: Fecha,
            idCliente: parseInt(idCliente),
            Importe: Importe,  // Enviar como número flotante
        };

        try {
            // Guardar en la base de datos
            const response = await fetch("./PostBackend/api.php/Facturas", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(nuevaFactura),
            });

            if (response.ok) {
                alert("Factura añadida correctamente.");
                this.datosVistaFacturas.arrayFacturas.push(nuevaFactura); // Añadir a la lista local
                this.generarTablaFacturas(); // Actualizar la tabla
                this.formularioFactura.style.display = "none"; // Ocultar el formulario
            } else {
                alert("Error al añadir la factura.");
            }
        } catch (error) {
            console.error("Error al guardar factura:", error);
            alert("Error al guardar factura.");
        }
    }

    // Función para mostrar los datos de la factura en el formulario para editarla
    editarFactura(event) {
        const idFactura = event.target.getAttribute("data-id");
        const factura = this.datosVistaFacturas.arrayFacturas.find(factura => factura.getId() === idFactura);

        if (factura) {
            // Cargar los datos de la factura seleccionada en el formulario
            document.getElementById("idFra").value = factura.getIdFra();
            document.getElementById("Fecha").value = factura.getFecha();
            document.getElementById("idCliente").value = factura.getIdCliente();
            document.getElementById("Importe").value = factura.getImporte();

            // Mostrar el formulario en modo edición
            this.formularioFactura.style.display = "block";

            // Cambiar el comportamiento del botón Guardar para actualizar la factura
            document.getElementById("btnGuardarFactura").removeEventListener("click", this.guardarFactura);
            document.getElementById("btnGuardarFactura").addEventListener("click", () => this.actualizarFactura(factura));
        }
    }

    // Función para actualizar una factura en la base de datos
    async actualizarFactura(factura) {
        const idFra = document.getElementById("idFra").value;
        const Fecha = document.getElementById("Fecha").value;
        const idCliente = document.getElementById("idCliente").value;
        const Importe = parseFloat(document.getElementById("Importe").value);

        if (!idFra || !Fecha || !idCliente || isNaN(Importe)) {
            alert("Todos los campos son obligatorios y el campo 'Importe' debe ser un número válido.");
            return;
        }

        const facturaActualizada = {
            idFra: idFra,
            Fecha: Fecha,
            idCliente: parseInt(idCliente),
            Importe: Importe,  // Enviar como número flotante
        };

        try {
            const idFactura = parseInt(document.getElementById("idFra").value);
            const response = await fetch(`./PostBackend/api.php/Facturas/${idFactura}`, {

                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(facturaActualizada),
            });

            if (response.ok) {
                alert("Factura actualizada correctamente.");
                // Actualizar la factura en la lista local
                const index = this.datosVistaFacturas.arrayFacturas.findIndex(f => f.getId() === factura.getId());
                if (index !== -1) {
                    this.datosVistaFacturas.arrayFacturas[index] = facturaActualizada;
                }
                this.generarTablaFacturas(); // Actualizar la tabla
                this.formularioFactura.style.display = "none"; // Ocultar el formulario
            } else {
                alert("Error al actualizar la factura.");
            }
        } catch (error) {
            console.error("Error al actualizar factura:", error);
            alert("Error al actualizar la factura.");
        }
    }

    // Función para cancelar la edición o adición de factura
    cancelarFormulario() {
        this.formularioFactura.style.display = "none";
        this.resetFormulario();
    }

    // Función para resetear el formulario
    resetFormulario() {
        document.getElementById("idFra").value = "";
        document.getElementById("Fecha").value = "";
        document.getElementById("idCliente").value = "";
        document.getElementById("Importe").value = "";
    }
}

new CtrlVistaFacturas();
