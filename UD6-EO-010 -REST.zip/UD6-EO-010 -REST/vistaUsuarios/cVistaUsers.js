// cVistaUsers.js
import { DatosVistaUsers } from "./mVistaUsers.js";

class CtrlVistaUsers {
    constructor() {
        this.vistaUsers = document.getElementById("Vistausers");
        this.tablaUsers = document.createElement("div");
        this.vistaUsers.appendChild(this.tablaUsers);

        // Formulario de añadir usuario
        this.formularioAñadir = document.getElementById("formularioAñadirUsuario");

        // Formulario de editar usuario (oculto por defecto)
        this.formularioEditar = document.getElementById("formularioEditar");

        // Crear una instancia del modelo
        this.datosVistaUsers = new DatosVistaUsers();

        // Esperar a que los datos se carguen y actualizar la vista
        setTimeout(() => this.generarTablaUsers(), 1000);

        // Vincular eventos de añadir y cancelar
        this.btnAbrirFormularioAñadir = document.getElementById("btnAbrirFormularioAñadir");
        this.btnAbrirFormularioAñadir.addEventListener("click", () => this.mostrarFormularioAñadir());

        this.cancelarAñadirBtn = document.getElementById("users_cancelarAñadir");
        this.cancelarAñadirBtn.addEventListener("click", () => this.cancelarAñadir());

        this.guardarNuevoUsuarioBtn = document.getElementById("users_guardarNuevoUsuario");
        this.guardarNuevoUsuarioBtn.addEventListener("click", () => this.guardarNuevoUsuario());

        // Eventos para editar y cancelar edición
        this.cancelarEdicionBtn = document.getElementById("users_cancelarEdicion");
        this.cancelarEdicionBtn.addEventListener("click", () => this.cancelarEdicion());
    }

    // Función para generar la tabla de usuarios
    generarTablaUsers() {
        const users = this.datosVistaUsers.getUsers();
        this.tablaUsers.innerHTML = ""; // Limpiar contenido previo

        if (users.length > 0) {
            let tablaHTML = `
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Acciones</th> <!-- Nueva columna para las acciones -->
                        </tr>
                    </thead>
                    <tbody>
            `;

            users.forEach((user, index) => {
                tablaHTML += `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.first_name}</td>
                        <td>${user.last_name}</td>
                        <td>${user.user_name}</td>
                        <td>${user.user_email}</td> <!-- Cambiado a user_email -->
                        <td>
                            <!-- Botón de eliminar -->
                            <button class="eliminar-btn" data-id="${index}">Eliminar</button><br />
                            <!-- Botón de editar -->
                            <button class="editar-btn" data-id="${index}">Editar</button>
                        </td>
                    </tr>
                `;
            });

            tablaHTML += `
                    </tbody>
                </table>
            `;
            this.tablaUsers.innerHTML = tablaHTML;

            // Añadir el evento para eliminar
            const botonesEliminar = document.querySelectorAll('.eliminar-btn');
            botonesEliminar.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const index = e.target.getAttribute('data-id');
                    this.eliminarUsuario(index);
                });
            });

            // Añadir el evento para editar
            const botonesEditar = document.querySelectorAll('.editar-btn');
            botonesEditar.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const index = e.target.getAttribute('data-id');
                    this.editarUsuario(index);
                });
            });
        } else {
            this.tablaUsers.innerHTML = "<p>No hay usuarios disponibles.</p>";
        }
    }

    // Función para mostrar el formulario de añadir usuario
    mostrarFormularioAñadir() {
        this.formularioAñadir.style.display = "block"; // Mostrar el formulario de añadir usuario
    }

    // Función para cancelar la adición de un nuevo usuario
    cancelarAñadir() {
        this.formularioAñadir.style.display = "none"; // Ocultar el formulario de añadir usuario
    }

    // Función para guardar un nuevo usuario
    async guardarNuevoUsuario() {
        const first_name = document.getElementById("users_first_name").value;
        const last_name = document.getElementById("users_last_name").value;
        const user_name = document.getElementById("users_user_name").value;
        const user_email = document.getElementById("users_user_email").value; // Asegurarse de que esté correctamente capturado
        const pwd = document.getElementById("users_pwd").value;
        const r_pwd = document.getElementById("users_r_pwd").value;

        // Validar que las contraseñas coincidan
        if (pwd !== r_pwd) {
            alert("Las contraseñas no coinciden");
            return;
        }

        // Crear un objeto con los datos del nuevo usuario
        const nuevoUsuario = {
            first_name,
            last_name,
            user_name,
            user_email, // Asegurarse de que el email esté aquí
            pwd,
            r_pwd
        };

        // Llamar al modelo para añadir el usuario al servidor
        await this.datosVistaUsers.agregarNuevoUsuario(nuevoUsuario);

        // Ocultar el formulario de añadir usuario después de guardar
        this.formularioAñadir.style.display = "none";

        // Actualizar la tabla después de añadir el nuevo usuario
        this.generarTablaUsers();
    }

    // Función para eliminar un usuario
    async eliminarUsuario(index) {
        // Llamar al modelo para eliminar el usuario
        await this.datosVistaUsers.eliminarUsuario(index);
        // Actualizar la tabla después de la eliminación
        this.generarTablaUsers();
    }

    // Función para editar un usuario
    editarUsuario(index) {
        const usuarios = this.datosVistaUsers.getUsers();

        // Verificar que el índice es válido
        if (!usuarios[index]) {
            console.error("Usuario no encontrado para el índice:", index);
            return;
        }

        const usuario = usuarios[index];

        // Llenar el formulario con los datos del usuario
        document.getElementById("useredit_idUsuario").value = usuario.id;
        document.getElementById("useredit_first_name").value = usuario.first_name;
        document.getElementById("useredit_last_name").value = usuario.last_name;
        document.getElementById("useredit_user_name").value = usuario.user_name;
        document.getElementById("useredit_user_email").value = usuario.user_email; // Cambiado a user_email
        document.getElementById("useredit_pwd").value = usuario.pwd;
        document.getElementById("useredit_r_pwd").value = usuario.r_pwd;

        // Mostrar el formulario de edición
        this.formularioEditar.style.display = "block"; // Mostrar el formulario de edición

        // Cambiar el texto del botón para "Actualizar Usuario"
        document.getElementById("users_guardarUsuario").textContent = "Actualizar Usuario";

        // Al hacer clic en el botón de "Guardar", se actualizarán los datos
        document.getElementById("users_guardarUsuario").onclick = () => this.actualizarUsuario(index);
    }

    // Función para cancelar la edición y ocultar el formulario
    cancelarEdicion() {
        this.formularioEditar.style.display = "none"; // Ocultar el formulario de edición
    }

    // Función para actualizar un usuario
    async actualizarUsuario(index) {
        const id = document.getElementById("useredit_idUsuario").value;
        const first_name = document.getElementById("useredit_first_name").value;
        const last_name = document.getElementById("useredit_last_name").value;
        const user_name = document.getElementById("useredit_user_name").value;
        const user_email = document.getElementById("useredit_user_email").value; // Cambiado a user_email
        const pwd = document.getElementById("useredit_pwd").value;
        const r_pwd = document.getElementById("useredit_r_pwd").value;

        // Validar que las contraseñas coincidan antes de enviar la solicitud
        if (pwd !== r_pwd) {
            alert("Las contraseñas no coinciden");
            return;
        }

        // Verificar que estamos obteniendo el usuario correcto
        const usuarioModificado = {
            id,
            first_name,
            last_name,
            user_name,
            user_email, // Cambiado a user_email
            pwd,
            r_pwd
        };

        // Asegurarse de que el índice sea válido antes de continuar
        const usuarios = this.datosVistaUsers.getUsers();
        if (!usuarios[index]) {
            console.error("Usuario no encontrado en el índice:", index);
            return;
        }

        // Llamar al modelo para actualizar el usuario
        await this.datosVistaUsers.modificarUsuario(usuarioModificado);

        // Ocultar el formulario de edición después de guardar
        this.formularioEditar.style.display = "none";

        // Actualizar la tabla después de modificar
        this.generarTablaUsers();
    }
}

new CtrlVistaUsers();
