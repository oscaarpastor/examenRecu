// mVistaUsers.js

// Definimos la clase `Users`, que representa a cada usuario
export class Users {
    constructor(id, first_name, last_name, user_name, user_email, pwd, r_pwd) {
        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.user_name = user_name;
        this.user_email = user_email; // Cambiado a user_email
        this.pwd = pwd;
        this.r_pwd = r_pwd;
    }
}

// Definimos la clase `DatosVistaUsers`, que maneja las operaciones con los usuarios
export class DatosVistaUsers {
    constructor() {
        this.arrayUsers = [];
        this.cargarUsers();  // Cargamos los usuarios al inicio
    }

    // Función para cargar los usuarios desde el servidor (simulación de una llamada API)
    async cargarUsers() {
        try {
            const response = await fetch("./PostBackend/api.php/users", {
                method: "GET",
                headers: {
                    "Content-type": "application/json",
                },
            });

            const data = await response.json();
            const usersRecords = data.users.records;

            usersRecords.forEach((item) => {
                // Creamos una nueva instancia de usuario y la añadimos al array
                const user = new Users(item[0], item[1], item[2], item[3], item[4], item[5], item[6]);
                this.arrayUsers.push(user);
            });
        } catch (error) {
            console.error("Error al cargar usuarios:", error);
        }
    }

    // Función para obtener todos los usuarios
    getUsers() {
        return this.arrayUsers;
    }

    // Función para eliminar un usuario
    async eliminarUsuario(index) {
        const userId = this.arrayUsers[index].id; // Obtener el ID del usuario a eliminar

        try {
            const response = await fetch(`./PostBackend/api.php/users/${userId}`, {
                method: 'DELETE',
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                }
            });

            if (response.ok) {
                // Si la eliminación es exitosa, eliminamos el usuario de la lista local
                this.arrayUsers.splice(index, 1);
                console.log("Usuario eliminado correctamente.");
            } else {
                console.error("Error al eliminar el usuario en el servidor.");
            }
        } catch (error) {
            console.error("Error al eliminar el usuario:", error);
        }
    }

    // Función para modificar un usuario
    async modificarUsuario(usuarioModificado) {
        // Encontramos el índice del usuario en el array
        const index = this.arrayUsers.findIndex(user => user.id === usuarioModificado.id);

        if (index !== -1) {
            // Si el usuario se encuentra, actualizamos los datos
            this.arrayUsers[index] = usuarioModificado;

            // Enviamos la actualización al servidor
            try {
                const response = await fetch(`./PostBackend/api.php/users/${usuarioModificado.id}`, {
                    method: "PUT",  // Suponiendo que usarás PUT para actualizar
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(usuarioModificado)
                });

                if (response.ok) {
                    console.log("Usuario actualizado correctamente.");
                } else {
                    console.error("Error al actualizar el usuario en el servidor.");
                }
            } catch (error) {
                console.error("Error al actualizar el usuario:", error);
            }
        } else {
            console.error("Usuario no encontrado para actualizar");
        }
    }

    // Función para agregar un nuevo usuario
    async agregarNuevoUsuario(usuario) {
        try {
            const response = await fetch("./PostBackend/api.php/users", {
                method: "POST",  // Usamos POST para añadir un nuevo usuario
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(usuario) // Aseguramos que el email se incluye en el cuerpo
            });

            if (response.ok) {
                const newUser = await response.json();
                console.log("Nuevo usuario añadido correctamente", newUser);

                // Añadir el nuevo usuario a la lista local
                this.arrayUsers.push(new Users(
                    newUser.id, newUser.first_name, newUser.last_name,
                    newUser.user_name, newUser.user_email, newUser.pwd, newUser.r_pwd
                ));
            } else {
                console.error("Error al añadir el nuevo usuario en el servidor.");
            }
        } catch (error) {
            console.error("Error al añadir el nuevo usuario:", error);
        }
    }
}
