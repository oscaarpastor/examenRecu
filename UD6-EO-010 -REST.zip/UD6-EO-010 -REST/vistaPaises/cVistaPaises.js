import { DatosVistaPaises } from './mVistaPaises.js';

var arrayClientes = []; 
var arrayPaises = []; 
var arrayFacturas = []; 

var mDatosPaises = new  DatosVistaPaises(arrayClientes, arrayPaises, arrayFacturas); 

class ctrl_VistaPaises {
    constructor() {
       
        arrayClientes = mDatosPaises.getClientes(); 
        arrayPaises = mDatosPaises.getPaises();      
        arrayFacturas = mDatosPaises.getFacturas();      
    
        // Vistas:
        this.VistaPaises = document.getElementById("VistaPaises");
        this.VistaClientes = document.getElementById("VistaClientes");
        
        this.ListaPaises= document.getElementById("VP_country"); 
        this.atras = document.getElementById('VP_atras');
        this.adelante = document.getElementById('VP_adelante');
       

        //this.ActivarVistaPaises();
        this.elemVisualizado = 0;
        
        // Eventos 
   
        this.ListaPaises.addEventListener("click", this.CambiarPais.bind(this), false);
        this.atras.addEventListener("click", this.Atras.bind(this), false);
        this.adelante.addEventListener("click", this.Adelante.bind(this), false);        
      


        setTimeout( () => this.Refres(), 1000); 
 
    }

   

    Refres() { // Es lo mismo que this.Cancel()      
      this.CargarPaises(); 
      this.GenerarTablaClientesFacturas();  // Actualizar la tabla
      document.getElementById('VP_country').getElementsByTagName('option')[this.elemVisualizado].selected = 'selected';
      console.log(arrayFacturas);
      console.log(arrayClientes);
    }
 
    // Función para mostrar los datos en la tabla
   GenerarTablaClientesFacturas() {        
        // Vacia tabla clientes!!!
        const divClientes = document.getElementById("VP_TablaClientes");
        divClientes.innerHTML = ''; // Limpiar contenido    
        let vista = "";
 
        arrayClientes.forEach((cliente, index) => {
            vista+="<center> CLIENTE </center>";
            vista+= '<table id="VP_TClientes"><tr><th>id</th><th>Nombre</th><th>Apellido</th><th>Email</th><th>Teléfono</th><th>País</th></tr>';    
            // Añade una fila con los datos del cliente
            var filacli = "<tr>"
                filacli+= "<td>"+cliente.id+"</td>";
                filacli+= "<td>"+cliente.fname+"</td>";
                filacli+= "<td>"+cliente.lname+"</td>";
                filacli+= "<td>"+cliente.email+"</td>";
                filacli+= "<td>"+cliente.phone+"</td>";
                filacli+= "<td>"+cliente.id_pais+"</td>";
                filacli+= "</td>";

            vista = vista + filacli; 
            vista+="</table><br>";
           
            if (this.TieneFacturas(cliente.id) ) {
                // Añade una fila QUE CONTIENE UNA TABLA con las facturas del cliente
                vista+=`<center> FACTURAS DEL CLIENTE ${cliente.firstname} </center>`;
                let TablaFra = `<table id="tFactCli_${cliente.id}" style="margin-left:20px">
                                <tr><th>id</th><th>idFra</th><th>Fecha</th><th>Importe</th></tr>
                              `;
                vista = vista + TablaFra;           

                arrayFacturas.forEach((Factura, index) => { 
                  if (Factura.idCliente==cliente.id) {
                    
                                    var FilaFactura = "<tr>";
                                        FilaFactura+="<td>"+Factura.id+"</td>";
                                        FilaFactura+="<td>"+Factura.idFra+"</td>";
                                        FilaFactura+="<td>"+Factura.Fecha+"</td>";                                  
                                        FilaFactura+="<td>"+Factura.Importe+"</td>";
                                        FilaFactura+="</tr>"
                                    vista = vista + FilaFactura;   
                  }                             
                })
                vista = vista + "</table>"; // Final tabla facturas
              }
        });
        divClientes.innerHTML = vista;
       
    }

    TieneFacturas(id){
      var Tiene=false;
      for (const Factura of arrayFacturas) {      
        if (Factura.idCliente==id) {
          Tiene = true; 
          break;
        }
      };
      return Tiene;
    }


    // Generar vista vertical añadiendo elementos de paises
    CargarPaises(){
      const select = document.querySelector('#VP_country');
      select.innerHTML = '';      

      arrayPaises.forEach((pais, index) => {
        const option = document.createElement('option');
        option.text=pais.Nombre;
        option.value=pais.id;
        select.appendChild(option);
      })
    }


    Atras() {
        if (this.elemVisualizado > 0) {
            this.elemVisualizado --;
            this.show();
        }
    }

    Adelante() {
        if (this.elemVisualizado < arrayPaises.length - 1) {
            this.elemVisualizado ++;         
            this.show();
        }
    }

    CambiarPais(){

      // Estas var no las usamos, pero podria .....
      // var pais_id = this.ListaPaises.value;
      // var NombrePais = this.ListaPaises.options[this.ListaPaises.selectedIndex].text;

      this.elemVisualizado = this.ListaPaises.selectedIndex;
      this.show();
    }

    show(){
      
      var Pais = arrayPaises[this.elemVisualizado];            

      console.log(Pais);
      arrayClientes = []; 
      arrayFacturas = []; 
      mDatosPaises.CargarClientesFacturasDeUnPais(Pais.id,arrayClientes, arrayFacturas); 

      setTimeout( () => this.Refres(), 1000);  
    }


   

  
}

var oCtrlVistaPaises = new ctrl_VistaPaises();
