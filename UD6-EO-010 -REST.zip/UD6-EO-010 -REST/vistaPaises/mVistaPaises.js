import { Cliente } from '../Pojos/PojoClientes.js';
import { Pais } from '../Pojos/PojoPaises.js';
import { Factura } from '../Pojos/PojoFacturas.js';

export class DatosVistaPaises {
  constructor(arrayClientes, arrayPaises, arrayFacturas) {
      this.arrayClientes = arrayClientes || [];      
      this.arrayPaises = arrayPaises || []; 
      this.arrayFacturas = arrayFacturas || []; 
      this.CargarPaisesYTablasRelacionadas();
  }


  async CargarPaisesYTablasRelacionadas(){
      
 
    var self = this;  // OJO muy importante

   
    fetch("./PostBackend/api.php/paises",  {
      method: 'GET',
      headers: {
        "Content-type":"application/x-www-form-urlencoded"
      },
    })
    .then((response) => response.json())
    .then((ObjPaises) => {
          var arrpaises = ObjPaises.paises.records;                   
          arrpaises.forEach((item, i) => {
            var pais= new Pais(item[0],item[1]);
            self.arrayPaises.push(pais);               
          });

          let idPais= self.arrayPaises[0].id;
          // pedimos los clientes y las facturas de los mismos !!
          self.CargarClientesFacturasDeUnPais(idPais, self.arrayClientes,self.arrayFacturas);
    })
    
  }


  CargarClientesFacturasDeUnPais(idPais,arrayClientes,  arrayFacturas ){
        this.arrayClientes = arrayClientes || [];  
        this.arrayFacturas = arrayFacturas || []; 
  
        var self = this;  // OJO muy importante

        console.log("REFRES !!!");     

        fetch("./PostBackend/api.php/clientes?filter[]=id_pais,eq,"+idPais,  {  // OBSERVA COMO SE SELECCIONA !!!
          method: 'GET',         
          headers: {
            "Content-type":"application/x-www-form-urlencoded"
          },
    
        })
        .then((response) => response.json())
        .then((ObjClientes) => { 
            var arrclientes=ObjClientes.clientes.records;
            arrclientes.forEach((item, i) => {

                  let nomPais = this.getNombrePais(item[7]);
                  var ocliente= new Cliente(item[0],item[1],item[2],item[3],item[4],item[5],item[6],item[7],nomPais);                   
                  self.arrayClientes.push(ocliente); 
                 
                  fetch("./PostBackend/api.php/Facturas?filter[]=idCliente,eq,"+ocliente.id,  {
                    method: 'GET',                  
                    headers: {
                      "Content-type":"application/x-www-form-urlencoded"
                    },
              
                  })
                  .then((response) => response.json())
                  .then((ObjFactures) => { 

                        var arrfactures=ObjFactures.Facturas.records;
                        arrfactures.forEach((factura, index) => {
                              var ofactura= new Factura(factura[0],factura[1],factura[2],factura[3],factura[4]);
                              self.arrayFacturas.push(ofactura);   
                        });

                  });
            
            })
        })
  }
   
 
  
  getClientes() {
      return this.arrayClientes;
  }
  getPaises() {
    return this.arrayPaises;
  }
  getFacturas() {
    return this.arrayFacturas;
  }

  getNombrePais(id) { // el id de la tabla no tiene por que ser el id del array
    for (var i =0; i<this.arrayPaises.length;i++){ 
      if (this.arrayPaises[i].id == id) 
        return this.arrayPaises[i].Nombre
     }
  }
 
}
