<?php


$servidor = "localhost";
$usuario = "root";
$password = "";
$bbdd = "ada";


$objeto=$_REQUEST['Objeto'];        // $objeto=$_POST['Objeto'];
$DATOS=json_decode($objeto,true);   //Convertir a un array asociativo (parameter to true)
$order  = $DATOS["order"];


//Crear la conexión
$conexion = new mysqli($servidor, $usuario, $password, $bbdd);
//echo $order;

if ($conexion->connect_error) {
  die("Error en la conexion: " + $conexion->connect_error);
} else {
        if ($order == "sel_idCliente") {

            $id_Cliente = $DATOS["id_Cliente"];
           //echo "Entra";

           $sql = "SELECT  id, idFra, Fecha, idCliente, Importe ".
                         "FROM Facturas ".                          
                         "WHERE idCliente=". $id_Cliente .";";
           // echo $sql;
           $resultado = $conexion->query($sql);           
           $salida = [];
           $salida = $resultado->fetch_all();

           echo json_encode($salida);
           

        } 
}

$conexion->close();
?>