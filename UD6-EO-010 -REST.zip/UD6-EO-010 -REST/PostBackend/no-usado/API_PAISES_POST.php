<?php


$servidor = "localhost";
$usuario = "root";
$password = "";
$bbdd = "ada";


$objeto=$_REQUEST['Objeto'];        // $objeto=$_POST['Objeto'];
$DATOS=json_decode($objeto,true);   //Convertir a un array asociativo (parameter to true)
$order  = $DATOS["order"];


//Crear la conexión
$conexion = new mysqli($servidor, $usuario, $password, $bbdd);
//echo $order;

if ($conexion->connect_error) {
  die("Error en la conexion: " + $conexion->connect_error);
} else {
        if ($order == "selectall") {

            $sql = "SELECT id, Nombre FROM paises"; 
            $resultado = $conexion->query($sql);
            $salida = array();
            $salida = $resultado->fetch_all();
            echo json_encode($salida);

        } else if ($order == "insert") {

            $Objeto = $DATOS["Objeto"];

            $country=json_decode($Objeto,true); //Convertir a un array asociativo (parameter to true)
           
            $sql = "INSERT INTO paises(Nombre) VALUES ('".$country['Nombre']."')";

            if ($conexion->query($sql) === TRUE) {
              //echo "<br>"; echo "nro registro insertado: ";
              $last_id = $conexion->insert_id; 
              echo $last_id;
            } else {
              echo ($resultado);
            }
        } else if ($order == "update") {

            $Objeto = $DATOS["Objeto"];

            $country=json_decode($Objeto,true); //Convertir a un array asociativo (parameter to true)          
            
            $sql = "UPDATE paises SET Nombre ='". $country['Nombre'] . "' WHERE id ='" . $country['id']."'";
            //echo $sql;
             
            if ($conexion->query($sql) === TRUE) {
              $last_id = $conexion->insert_id;
              echo $last_id;
            } else {
              echo "Error";
            }
            

        } else if($order=="delete"){            
            $id = $DATOS["id"];
            $sql = "DELETE FROM paises WHERE id='$id';";
            //echo $sql;
            $resultado = $conexion->query($sql);
            echo ($resultado);
        }
}

$conexion->close();
?>