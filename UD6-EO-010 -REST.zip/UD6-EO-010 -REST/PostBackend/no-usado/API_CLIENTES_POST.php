<?php


$servidor = "localhost";
$usuario = "root";
$password = "";
$bbdd = "ada";


$objeto=$_REQUEST['Objeto'];        // $objeto=$_POST['Objeto'];
$DATOS=json_decode($objeto,true);  //Convertir a un array asociativo (parameter to true)
$order  = $DATOS["order"];
// $cliente= en cada op sacar de $DATOS


//Crear la conexión
$conexion = new mysqli($servidor, $usuario, $password, $bbdd);
//echo $order;

if ($conexion->connect_error) {
  die("Error en la conexion: " + $conexion->connect_error);
} else {
        if ($order == "selectall") {

            $sql = "SELECT clientes.id, genero, fname, lname,email,phone,passwd,id_pais, paises.Nombre ".
                          "FROM clientes, paises ".
                          "WHERE clientes.id_pais=paises.id"; 

            $resultado = $conexion->query($sql);
            $salida = array();
            $salida = $resultado->fetch_all();
            echo json_encode($salida);
          
 	       } else if ($order == "sel_idpais") {

     	      $id_pais = $DATOS["id_pais"];
            // echo $id_pais;

            $sql = "SELECT id, genero, fname, lname,email,phone,passwd ,id_pais ".
                          "FROM clientes ".                          
                          "WHERE id_pais='$id_pais';";
            //;echo $sql;

            $resultado = $conexion->query($sql);
            $salida = array();
            $salida = $resultado->fetch_all();
            echo json_encode($salida);

        } else if ($order == "insert") {

            $Objeto = $DATOS["Objeto"];

            $cliente=json_decode($Objeto,true); //Convertir a un array asociativo (parameter to true)
           
            $sql = "INSERT INTO clientes(genero, fname, lname,email,phone,passwd,id_pais) VALUES ('". 
                                        $cliente['title']. "','" .
                                        $cliente['firstname']. "','" . 
                                        $cliente['lastname']. "','" .
                                        $cliente['email']. "','" .
                                        $cliente['phone'] ."','". 
                                        $cliente['password']."','".
                                        $cliente['id_pais']."')";

            if ($conexion->query($sql) === TRUE) {
              //echo "<br>"; echo "nro registro insertado: ";
              $last_id = $conexion->insert_id; 
              echo $last_id;
            } else {
              echo ($resultado);
            }
        } else if ($order == "update") {

            $Objeto = $DATOS["Objeto"];

            $cliente=json_decode($Objeto,true); //Convertir a un array asociativo (parameter to true)          
            
            $sql = "UPDATE clientes SET genero ='" . $cliente['title'] .
                                    "', fname ='"  . $cliente['firstname'] .
                                    "', lname ='"  . $cliente['lastname'] .
                                    "', email ='"  . $cliente['email'] .
                                    "', phone ='"  . $cliente['phone'] .
                                    "', passwd ='" . $cliente['password'] .
                                    "', id_pais ='". $cliente['id_pais'] . "' WHERE id ='" . $cliente['id']."'";
            //echo $sql;
             
            if ($conexion->query($sql) === TRUE) {
              $last_id = $conexion->insert_id;
              echo $last_id;
            } else {
              echo "Error";
            }
            

        } else if($order=="delete"){            
            $id = $DATOS["id"];
            $sql = "DELETE FROM clientes WHERE id='$id';";
            //echo $sql;
            $resultado = $conexion->query($sql);
            echo ($resultado);
            
        }
}

$conexion->close();
?>