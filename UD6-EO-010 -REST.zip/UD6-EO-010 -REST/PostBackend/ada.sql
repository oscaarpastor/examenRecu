-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 21-11-2024 a las 13:56:02
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ada`
--
CREATE DATABASE IF NOT EXISTS `ada` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ada`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
CREATE TABLE IF NOT EXISTS `alumnos` (
  `idAlumno` int(11) NOT NULL AUTO_INCREMENT,
  `alumno` text NOT NULL,
  `puntuacion` decimal(10,0) NOT NULL,
  PRIMARY KEY (`idAlumno`),
  KEY `idAlumno` (`idAlumno`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`idAlumno`, `alumno`, `puntuacion`) VALUES
(1, 'Toni', 10),
(2, 'Toni', 7),
(3, 'Carlos', 4),
(4, 'Jose', 3),
(5, 'juan', 8),
(6, 'Pepe', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `genero` text NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `passwd` text NOT NULL,
  `id_pais` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `genero`, `fname`, `lname`, `email`, `phone`, `passwd`, `id_pais`) VALUES
(1, 'mr', 'elviss', 'WiliamsSSSSS', 'elvis@yo.es', '1291212', '121212', '1'),
(33, 'mrs', 'Emmassss', 'ASS', 'emmas@gma.es', '123456789', '123!a', '2'),
(34, 'mr', 'antoniett', 'Professor', 'ja.francopasto@edu.gva.es', '123456789', '123!a', '3'),
(35, 'miss', 'Margaret', 'Collins', 'margaret@collins.cat', '123456789', '123!a', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Facturas`
--

DROP TABLE IF EXISTS `Facturas`;
CREATE TABLE IF NOT EXISTS `Facturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idFra` text NOT NULL,
  `Fecha` date NOT NULL,
  `idCliente` int(10) NOT NULL,
  `Importe` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFra` (`idFra`(768))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `Facturas`
--

INSERT INTO `Facturas` (`id`, `idFra`, `Fecha`, `idCliente`, `Importe`) VALUES
(1, '00001', '2024-11-03', 1, 15.10),
(2, '00012', '2024-10-01', 1, 13.10),
(3, '00003', '2022-11-03', 34, 125.78),
(4, '00004', '2023-12-03', 34, 105.25),
(5, '00005', '2022-11-03', 35, 50.15),
(6, '00006', '2023-02-03', 35, 12.25),
(7, '00007', '2019-05-03', 33, 10.25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `LineasFacturas`
--

DROP TABLE IF EXISTS `LineasFacturas`;
CREATE TABLE IF NOT EXISTS `LineasFacturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idFra` int(11) NOT NULL,
  `cantidad` decimal(11,2) NOT NULL,
  `Descripcion` text NOT NULL,
  `Precio` decimal(11,2) NOT NULL,
  `Foto` text NOT NULL,
  `idProducto` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idCliente` (`idFra`),
  KEY `idFra` (`idFra`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `LineasFacturas`
--

INSERT INTO `LineasFacturas` (`id`, `idFra`, `cantidad`, `Descripcion`, `Precio`, `Foto`, `idProducto`) VALUES
(1, 1, 2.00, 'Cocacola', 4.00, 'imgs/cocacola.png', 1),
(4, 1, 1.00, 'Bravas', 10.00, 'imgs/bravas.png', 2),
(5, 1, 1.00, 'Cafe', 1.10, 'imgs/cafe.png', 3),
(6, 12, 1.00, 'Bocata pernil', 10.00, 'imgs/bocata.png', 10),
(7, 12, 1.00, 'Cocacol a Zero', 2.00, 'imgs/cerveza.png', 1),
(8, 12, 1.00, 'Cremaet', 1.10, 'imgs/cafe.png', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

DROP TABLE IF EXISTS `paises`;
CREATE TABLE IF NOT EXISTS `paises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id`, `Nombre`) VALUES
(1, 'Spain'),
(2, 'Germany'),
(3, 'China');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Productos`
--

DROP TABLE IF EXISTS `Productos`;
CREATE TABLE IF NOT EXISTS `Productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` text NOT NULL,
  `Foto` text NOT NULL,
  `Precio` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `Productos`
--

INSERT INTO `Productos` (`id`, `Nombre`, `Foto`, `Precio`) VALUES
(1, 'Cocacola', 'imgs/cocacola.png', 2.00),
(2, 'Bravas', 'imgs/bravas.png', 10.00),
(3, 'Cafe', 'imgs/cafe.png', 1.10),
(4, 'Bocata pernil', 'imgs/bocata.png', 10.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `user_name` text NOT NULL,
  `email` text NOT NULL,
  `pwd` text NOT NULL,
  `r_pwd` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `user_name`, `email`, `pwd`, `r_pwd`) VALUES
(2, 'toni', 'toni', 'toni', 'toni@e.es', '$2y$10$PePxttzi7k04bBi7gUVd/O6fZo.n8BI/YG8RpeWggs3ll/dNLu2g6', '$2y$10$PePxttzi7k04bBi7gUVd/O6fZo.n8BI/YG8RpeWggs3ll/dNLu2g6'),
(3, 'atre', 'atre', 'atre', 'a@ed.es', '$2y$10$gGbjstCqjHoceuG7TAeVx.Meq1cLe.lKT7J2NDH7p/jvHmZFQv4du', '$2y$10$Pn9ueVZPH7a.UPEmTlzEbuCCDyyQ/QKNM64GmnflsOvF.lg1iD0o6');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
