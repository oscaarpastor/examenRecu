import { DatosVistaProductos } from "./mVistaProductos.js";

class CtrlVistaProductos {
    constructor() {
        this.vistaProductos = document.getElementById("VistaProductos");
        this.tablaProductos = document.getElementById("VP_TablaProductos");
        this.formulario = document.getElementById("formularioProducto");
        this.btnGuardarProducto = document.getElementById("btnGuardarProducto");
        this.inputId = document.getElementById("productoId");
        this.inputNombre = document.getElementById("productoNombre");
        this.inputPrecio = document.getElementById("productoPrecio");

        this.datosVistaProductos = new DatosVistaProductos();
        this.modoEdicion = false; // Modo edición o creación

        // Inicializar tabla
        setTimeout(() => this.generarTablaProductos(), 1000);

        // Evento para guardar producto
        this.btnGuardarProducto.addEventListener("click", () => this.guardarProducto());
    }

    // Función para generar la tabla de productos
    generarTablaProductos() {
        const productos = this.datosVistaProductos.getProductos();
        this.tablaProductos.innerHTML = ""; // Limpiar contenido previo

        if (productos.length > 0) {
            let tablaHTML = `
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Precio</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            productos.forEach((producto) => {
                tablaHTML += `
                    <tr>
                        <td>${producto.id}</td>
                        <td>${producto.Nombre}</td>
                        <td>${producto.Precio} €</td>
                        <td>
                            <button class="btnEditar" data-id="${producto.id}">Editar</button>
                            <button class="btnEliminar" data-id="${producto.id}">Eliminar</button>
                        </td>
                    </tr>
                `;
            });

            tablaHTML += `
                    </tbody>
                </table>
            `;
            this.tablaProductos.innerHTML = tablaHTML;

            // Agregar eventos a los botones de editar y eliminar
            document.querySelectorAll(".btnEditar").forEach((btn) => {
                btn.addEventListener("click", (event) => this.editarProducto(event));
            });

            document.querySelectorAll(".btnEliminar").forEach((btn) => {
                btn.addEventListener("click", (event) => this.eliminarProducto(event));
            });
        } else {
            this.tablaProductos.innerHTML = "<p>No hay productos disponibles.</p>";
        }
    }

    // Función para guardar un producto (nuevo o editado)
    // Función para guardar un producto (nuevo o editado)
async guardarProducto() {
    const nombre = this.inputNombre.value;
    const precio = this.inputPrecio.value;

    if (!nombre || !precio) {
        alert("Todos los campos son obligatorios.");
        return;
    }

    // En modo inserción ignoramos el valor del inputId (que estará vacío)
    let producto = { Nombre: nombre, Precio: parseFloat(precio) };

    try {
        if (this.modoEdicion) {
            // En modo edición usamos el id del input
            const id = parseInt(this.inputId.value);
            producto.id = id; // Aseguramos que incluya el id

            const response = await fetch(`./PostBackend/api.php/Productos/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(producto),
            });

            if (response.ok) {
                alert("Producto actualizado correctamente.");
                // Actualizamos el array local
                this.datosVistaProductos.arrayProductos = this.datosVistaProductos.arrayProductos.map((p) =>
                    p.id === producto.id ? producto : p
                );
            } else {
                alert("Error al actualizar el producto.");
            }
        } else {
            // Crear producto nuevo
            const response = await fetch(`./PostBackend/api.php/Productos`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(producto),
            });

            if (response.ok) {
                // Se espera que el API devuelva el id del nuevo producto.
                // Por ejemplo, el API puede retornar un objeto { id: 123 }
                const data = await response.json();
                producto.id = data.id; // Asignamos el id devuelto
                alert("Producto añadido correctamente.");
                this.datosVistaProductos.arrayProductos.push(producto);
            } else {
                alert("Error al añadir el producto.");
            }
        }
    } catch (error) {
        console.error("Error al guardar producto:", error);
        alert("Error al guardar producto. Ver consola para más detalles.");
    }

    this.generarTablaProductos(); // Actualizar tabla
    this.formulario.style.display = "none"; // Ocultar formulario
}


    // Función para editar un producto
    editarProducto(event) {
        const idProducto = parseInt(event.target.getAttribute("data-id"));
        const producto = this.datosVistaProductos.arrayProductos.find((p) => p.id === idProducto);

        if (producto) {
            this.mostrarFormulario(producto);
        }
    }

    // Función para mostrar el formulario con los datos del producto a editar
    mostrarFormulario(producto) {
        // Mostrar el formulario con datos si es edición
        this.formulario.style.display = "block";

        if (producto) {
            this.inputId.value = producto.id;
            this.inputNombre.value = producto.Nombre;
            this.inputPrecio.value = producto.Precio;
            this.modoEdicion = true; // Cambiar a modo edición
        }
    }

    // Función para eliminar un producto
    async eliminarProducto(event) {
        const idProducto = parseInt(event.target.getAttribute("data-id"));

        if (confirm("¿Estás seguro de que quieres eliminar este producto?")) {
            try {
                const response = await fetch(`./PostBackend/api.php/Productos/${idProducto}`, {
                    method: "DELETE",
                });

                if (response.ok) {
                    alert("Producto eliminado correctamente.");
                    this.datosVistaProductos.arrayProductos = this.datosVistaProductos.arrayProductos.filter(
                        (producto) => producto.id !== idProducto
                    );
                    this.generarTablaProductos(); // Actualizar tabla
                } else {
                    alert("Error al eliminar el producto.");
                }
            } catch (error) {
                console.error("Error al eliminar producto:", error);
                alert("Error al eliminar producto. Ver consola para más detalles.");
            }
        }
    }
}

new CtrlVistaProductos();
