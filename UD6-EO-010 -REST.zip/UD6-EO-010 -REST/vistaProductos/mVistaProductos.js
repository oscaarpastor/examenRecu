export class Productos {
    constructor(id, Nombre, Foto, Precio) {
        this.id = id;
        this.Nombre = Nombre;
        this.Foto = Foto;
        this.Precio = Precio;
    }

    getId() {
        return this.id;
    }

    getNombre() {
        return this.Nombre;
    }

    getFoto() {
        return this.Foto;
    }

    getPrecio() {
        return this.Precio;
    }
}

export class DatosVistaProductos {
    constructor() {
        this.arrayProductos = [];
        this.cargarProductos();
    }

    async cargarProductos() {
        try {
            const response = await fetch("./PostBackend/api.php/Productos", {
                method: "GET",
                headers: {
                    "Content-type": "application/json",
                },
            });
            const data = await response.json();

            if (data && data.Productos && Array.isArray(data.Productos.records)) {
                const productosRecords = data.Productos.records;

                productosRecords.forEach((item) => {
                    if (item.length === 4) {
                        const producto = new Productos(item[0], item[1], item[2], item[3]);
                        this.arrayProductos.push(producto);
                    } else {
                        console.error("Formato de datos incorrecto para producto:", item);
                    }
                });
            } else {
                console.error("Respuesta de la API no válida:", data);
            }
        } catch (error) {
            console.error("Error al cargar productos:", error);
        }
    }

    getProductos() {
        return this.arrayProductos;
    }
}
