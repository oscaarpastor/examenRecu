class ctrl_menu{
    constructor() { 
        // Vistas:
            this.VistaPaises = document.getElementById("VistaPaises");
            this.VistaClientes = document.getElementById("VistaClientes");
            this.VistaAlumnos = document.getElementById("VistaAlumnos");
            this.VistaProductos = document.getElementById("VistaProductos");
            this.Vistausers = document.getElementById("Vistausers");
            this.VistaFacturas = document.getElementById("VistaFacturas");
            this.VistaLineasFacturas = document.getElementById("VistaLineasFacturas");

            // Botones del menú:
            this.Clientes = document.getElementById('M_clientes');
            this.Paises = document.getElementById('M_paises');
            this.Alumnos = document.getElementById('M_alumnos');
            this.Productos = document.getElementById('M_productos');
            this.users = document.getElementById('M_users');
            this.Facturas = document.getElementById('M_Facturas');
            this.LineasFacturas = document.getElementById('M_LineasFacturas');


        // Eventos:
            this.Clientes.addEventListener("click", this.ActivarVistaClientes.bind(this), false);
            this.Paises.addEventListener("click", this.ActivarVistaPaises.bind(this), false);
            this.Alumnos.addEventListener("click", this.ActivarVistaAlumnos.bind(this), false);
            this.Productos.addEventListener("click", this.ActivarVistaProductos.bind(this), false);
            this.users.addEventListener("click", this.ActivarVistausers.bind(this), false);
            this.Facturas.addEventListener("click", this.ActivarVistaFacturas.bind(this), false);
            this.LineasFacturas.addEventListener("click", this.ActivarVistaLineasFacturas.bind(this), false);


        this.ActivarVistaPaises(); // Vista por defecto
    
    }

    ActivarVistaClientes(){
        this.OcultarTodo()
        this.VistaPaises.style.display      =   'none';
        this.VistaClientes.style.display    =   'block';      
    }

    ActivarVistaPaises(){
        this.OcultarTodo()
        this.VistaPaises.style.display      =   'block';
        this.VistaClientes.style.display    =   'none';       
    }

    ActivarVistaAlumnos(){
        this.OcultarTodo()
        this.VistaAlumnos.style.display      =   'block';       
    }

    ActivarVistaProductos(){
        this.OcultarTodo()
        this.VistaProductos.style.display     =   'block';       
    }

    ActivarVistausers(){
        this.OcultarTodo()
        this.Vistausers.style.display      =   'block';       
    }

    ActivarVistaFacturas(){
        this.OcultarTodo()
        this.VistaFacturas.style.display      =   'block';       
    }

    ActivarVistaLineasFacturas() {
        this.OcultarTodo();
        this.VistaLineasFacturas.style.display      =   'block';  
    }
    
    

    OcultarTodo(){
        this.VistaPaises.style.display      =   'none';
        this.VistaClientes.style.display    =   'none';
        this.VistaAlumnos.style.display     =   'none';
        this.VistaProductos.style.display   =   'none';
        this.Vistausers.style.display       =   'none';
        this.VistaFacturas.style.display    =   'none';
        this.VistaLineasFacturas.style.display    =   'none';

    }
} 

var oMenu = new ctrl_menu(); 