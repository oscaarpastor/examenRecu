// Archivo: mVistaAlumnos.js

export class Alumnos {
  constructor(idAlumno, alumno, puntuacion) {
    this.idAlumno = idAlumno;
    this.alumno = alumno;
    this.puntuacion = puntuacion;
  }
}

export class DatosVistaAlumnos {
  constructor() {
    this.arrayAlumnos = [];
    // Guardamos la promesa de carga para saber cuándo finalizó
    this.loadingPromise = this.cargarAlumnos();
  }

  async cargarAlumnos() {
    try {
      const response = await fetch("./PostBackend/api.php/alumnos", {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        throw new Error("Error en la respuesta del servidor");
      }
      const data = await response.json();
      // Se asume que la estructura es data.alumnos.records
      const alumnosRecords = data.alumnos.records;
      alumnosRecords.forEach((item) => {
        const alumno = new Alumnos(item[0], item[1], item[2]);
        this.arrayAlumnos.push(alumno);
      });
    } catch (error) {
      console.error("Error al cargar alumnos:", error);
    }
  }

  getAlumnos() {
    return this.arrayAlumnos;
  }
}
