// Archivo: cVistaAlumnos.js

// Importar el modelo
import { DatosVistaAlumnos, Alumnos } from "./mVistaAlumnos.js";

class CtrlVistaAlumnos {
  constructor() {
    // Elementos del DOM
    this.vistaAlumnos = document.getElementById("VistaAlumnos");
    this.tablaAlumnos = document.getElementById("VP_TablaAlumnos");

    // Instancia del modelo
    this.datosVistaAlumnos = new DatosVistaAlumnos();
    this.alumnoEnEdicion = null; // Para rastrear si se está editando

    // Configurar el formulario de agregar/modificar
    this.configurarFormulario();

    // Configurar el eliminador por criterio para alumnos
    this.configurarEliminadorPorCriterio();

    // Esperar un segundo y luego refrescar la tabla
    setTimeout(() => this.Refres(), 1000);
  }

  /**
   * Refresca la vista generando la tabla con los datos actuales y actualiza el dropdown de valores.
   */
  Refres() {
    this.generarTablaAlumnos();
    // Actualizamos el desplegable de valores, ya que puede haber cambios en los datos
    this.actualizarDropdownValores();
  }

  /**
   * Genera la tabla de alumnos.
   */
  generarTablaAlumnos() {
    const alumnos = this.datosVistaAlumnos.getAlumnos();
    this.tablaAlumnos.innerHTML = "";

    if (alumnos.length > 0) {
      let tablaHTML = `
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Alumno</th>
              <th>Puntuación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
      `;

      alumnos.forEach((alumno) => {
        tablaHTML += `
          <tr>
            <td>${alumno.idAlumno}</td>
            <td>${alumno.alumno}</td>
            <td>${alumno.puntuacion}</td>
            <td>
              <button class="btnModificar" data-id="${alumno.idAlumno}">Modificar</button>
              <button class="btnEliminar" data-id="${alumno.idAlumno}">Eliminar</button>
            </td>
          </tr>
        `;
      });

      tablaHTML += `
          </tbody>
        </table>
      `;
      this.tablaAlumnos.innerHTML = tablaHTML;

      // Asignar eventos a los botones de modificar y eliminar individual
      document.querySelectorAll(".btnModificar").forEach((boton) => {
        boton.addEventListener("click", (event) => this.modificarAlumno(event));
      });
      document.querySelectorAll(".btnEliminar").forEach((boton) => {
        boton.addEventListener("click", (event) => this.eliminarAlumno(event));
      });
    } else {
      this.tablaAlumnos.innerHTML = "<p>No hay alumnos disponibles.</p>";
    }
  }

  /**
   * Configura el formulario para agregar o modificar alumnos.
   */
  configurarFormulario() {
    const btnAbrirFormulario = document.getElementById("btnAbrirFormulario");
    const formularioAlumno = document.getElementById("formularioAlumno");
    const btnGuardarAlumno = document.getElementById("btnGuardarAlumno");
    const formAlumno = document.getElementById("formAlumno");

    // Mostrar formulario para nuevo alumno
    btnAbrirFormulario.addEventListener("click", () => {
      this.alumnoEnEdicion = null;
      formAlumno.reset();
      formularioAlumno.style.display = "block";
    });

    // Guardar (agregar o modificar)
    btnGuardarAlumno.addEventListener("click", async () => {
      const alumnoInput = document.getElementById("alumno");
      const puntuacionInput = document.getElementById("puntuacion");

      const alumnoValor = alumnoInput.value.trim();
      const puntuacionNum = parseFloat(puntuacionInput.value);

      if (!alumnoValor || isNaN(puntuacionNum)) {
        alert("Por favor, completa todos los campos correctamente.");
        return;
      }

      const puntuacionValor = puntuacionNum.toFixed(2);
      const datosAlumno = { alumno: alumnoValor, puntuacion: puntuacionValor };

      if (this.alumnoEnEdicion) {
        // Modificar alumno existente
        const idAlumno = this.alumnoEnEdicion;
        try {
          const response = await fetch(`./PostBackend/api.php/alumnos/${idAlumno}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datosAlumno),
          });

          if (response.ok) {
            const alumnoMod = this.datosVistaAlumnos.arrayAlumnos.find(
              (a) => a.idAlumno == idAlumno
            );
            if (alumnoMod) {
              alumnoMod.alumno = alumnoValor;
              alumnoMod.puntuacion = puntuacionValor;
            }
            alert("Alumno modificado correctamente.");
            formularioAlumno.style.display = "none";
            setTimeout(() => this.Refres(), 1000);
          } else {
            alert("Error al modificar el alumno.");
          }
        } catch (error) {
          console.error("Error al modificar alumno:", error);
        }
      } else {
        // Agregar nuevo alumno
        try {
          const response = await fetch("./PostBackend/api.php/alumnos", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datosAlumno),
          });

          if (response.ok) {
            const data = await response.json();
            const nuevoId = data.idAlumno || Date.now();
            this.datosVistaAlumnos.arrayAlumnos.push(
              new Alumnos(nuevoId, alumnoValor, puntuacionValor)
            );
            alert("Alumno añadido correctamente.");
            formularioAlumno.style.display = "none";
            setTimeout(() => this.Refres(), 1000);
          } else {
            alert("Error al añadir alumno.");
          }
        } catch (error) {
          console.error("Error al añadir alumno:", error);
        }
      }
    });
  }

  /**
   * Configura la funcionalidad para eliminar varios alumnos según un criterio.
   * Se esperan tres elementos en el HTML:
   * - Un select con id="criterioSelectAlumnos" para elegir la columna (p.ej., "alumno" o "puntuacion").
   * - Un select con id="valorSelectAlumnos" para elegir el valor a filtrar (se actualizará dinámicamente).
   * - Un botón con id="btnEliminarCriterioAlumnos" para iniciar la eliminación.
   */
  configurarEliminadorPorCriterio() {
    this.criterioSelectAlumnos = document.getElementById("criterioSelectAlumnos");
    this.valorSelectAlumnos = document.getElementById("valorSelectAlumnos");
    this.btnEliminarCriterioAlumnos = document.getElementById("btnEliminarCriterioAlumnos");

    if (!this.btnEliminarCriterioAlumnos) {
      console.error("No se encontró btnEliminarCriterioAlumnos. Verifica el ID en el HTML.");
    } else {
      this.btnEliminarCriterioAlumnos.addEventListener("click", this.eliminarPorCriterio.bind(this), false);
      console.log("Listener asignado a btnEliminarCriterioAlumnos.");
    }

    // Actualizar el desplegable de valores al cambiar el criterio seleccionado
    this.criterioSelectAlumnos.addEventListener("change", () => this.actualizarDropdownValores());
  }

  /**
   * Actualiza el desplegable de valores según el criterio seleccionado.
   */
  actualizarDropdownValores() {
    const criterio = this.criterioSelectAlumnos.value; // "alumno" o "puntuacion"
    // Vaciar el select de valores
    this.valorSelectAlumnos.innerHTML = "";

    // Extraer valores únicos usando un Set
    const valoresUnicos = new Set();
    this.datosVistaAlumnos.arrayAlumnos.forEach((alumno) => {
      valoresUnicos.add(alumno[criterio]);
    });

    // Agregar una opción por cada valor único
    valoresUnicos.forEach((valor) => {
      const option = document.createElement("option");
      option.value = valor;
      option.textContent = valor;
      this.valorSelectAlumnos.appendChild(option);
    });
  }

  /**
   * Elimina todos los alumnos que cumplan el criterio seleccionado.
   */
  eliminarPorCriterio() {
    const criterio = this.criterioSelectAlumnos.value; // "alumno" o "puntuacion"
    const valor = this.valorSelectAlumnos.value;

    if (!valor) {
      alert("Debes seleccionar un valor para filtrar.");
      return;
    }
    console.log("Eliminar alumnos por criterio:", criterio, "con valor:", valor);

    let eliminado = false;
    // Recorrer el array local desde el final
    for (let i = this.datosVistaAlumnos.arrayAlumnos.length - 1; i >= 0; i--) {
      let coincide = false;
      if (criterio === "puntuacion") {
        // Comparar numéricamente (formateando a dos decimales)
        const numAlumno = parseFloat(this.datosVistaAlumnos.arrayAlumnos[i][criterio]);
        const numValor = parseFloat(valor);
        if (!isNaN(numAlumno) && !isNaN(numValor) && numAlumno.toFixed(2) === numValor.toFixed(2)) {
          coincide = true;
        }
      } else {
        // Comparar cadenas (ignorando mayúsculas/minúsculas)
        if (
          String(this.datosVistaAlumnos.arrayAlumnos[i][criterio])
            .toLowerCase() === valor.toLowerCase()
        ) {
          coincide = true;
        }
      }

      if (coincide) {
        console.log("Eliminando alumno en índice", i, "con", criterio, "=", this.datosVistaAlumnos.arrayAlumnos[i][criterio]);
        const idAlumno = this.datosVistaAlumnos.arrayAlumnos[i].idAlumno;
        // Enviar DELETE a la API para este alumno
        fetch(`./PostBackend/api.php/alumnos/${idAlumno}`, {
          method: "DELETE",
        })
          .then((response) => {
            if (response.ok) {
              console.log("Alumno con id", idAlumno, "eliminado del servidor.");
            } else {
              console.error("Error al eliminar alumno con id", idAlumno);
            }
          })
          .catch((error) => {
            console.error("Error en fetch DELETE:", error);
          });
        // Eliminar del array local
        this.datosVistaAlumnos.arrayAlumnos.splice(i, 1);
        eliminado = true;
      }
    }
    if (!eliminado) {
      alert("No se encontró ningún alumno con ese valor.");
    } else {
      alert("Alumnos eliminados según el criterio.");
    }
    setTimeout(() => this.Refres(), 1000);
  }

  /**
   * Elimina un alumno individual.
   */
  async eliminarAlumno(event) {
    const idAlumno = event.target.getAttribute("data-id");
    if (confirm("¿Estás seguro de que quieres eliminar este alumno?")) {
      try {
        const response = await fetch(`./PostBackend/api.php/alumnos/${idAlumno}`, {
          method: "DELETE",
        });
        if (response.ok) {
          this.datosVistaAlumnos.arrayAlumnos = this.datosVistaAlumnos.arrayAlumnos.filter(
            (a) => a.idAlumno != idAlumno
          );
          alert("Alumno eliminado correctamente.");
          setTimeout(() => this.Refres(), 1000);
        } else {
          alert("Error al eliminar el alumno.");
        }
      } catch (error) {
        console.error("Error al eliminar alumno:", error);
      }
    }
  }

  /**
   * Prepara el formulario para modificar un alumno.
   */
  modificarAlumno(event) {
    const idAlumno = event.target.getAttribute("data-id");
    const alumno = this.datosVistaAlumnos.getAlumnos().find((a) => a.idAlumno == idAlumno);
    if (alumno) {
      const formularioAlumno = document.getElementById("formularioAlumno");
      formularioAlumno.style.display = "block";
      document.getElementById("alumno").value = alumno.alumno;
      document.getElementById("puntuacion").value = alumno.puntuacion;
      this.alumnoEnEdicion = idAlumno;
    }
  }
}

// Inicializar el controlador
new CtrlVistaAlumnos();
