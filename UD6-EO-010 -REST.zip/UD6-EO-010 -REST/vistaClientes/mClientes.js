import { Cliente } from '../Pojos/PojoClientes.js';
import { Pais } from '../Pojos/PojoPaises.js';

export class DatosVistaClientes {
  constructor(arrayClientes, arrayPaises) {
      this.arrayClientes = arrayClientes || [];      
      this.arrayPaises = arrayPaises || []; 

      // Cargar primero los países y luego los clientes (solución 2)
      this.CargarClientesPaisesOk();
  }

  // SOLUCION 2: PEDIR PRIMERO LOS PAISES Y DESPUES LOS CLIENTES, RELLENAR EL CLIENTE CORRECTAMENTE:
  CargarClientesPaisesOk(){
    var self = this;  // OJO muy importante
    // Primero se cargan los países
    fetch("./PostBackend/api.php/paises",  {
      method: 'GET',
      headers: {
        "Content-type":"application/x-www-form-urlencoded"
      },
    })
    .then((response) => response.json())
    .then((ObjPaises) => {
          var arrpaises = ObjPaises.paises.records;                   
          arrpaises.forEach((pais, i) => {
            var opais = new Pais(pais[0], pais[1]);
            self.arrayPaises.push(opais);               
          });

          // Una vez cargados los países, se cargan los clientes
          fetch("./PostBackend/api.php/clientes",  {
            method: 'GET',     
            headers: {
              "Content-type":"application/x-www-form-urlencoded"
            },
          })
          .then((response) => response.json())
          .then((ObjClientes) => {
                  var arrclientes = ObjClientes.clientes.records;
                  arrclientes.forEach((cliente, i) => {
                    let nomPais = self.getNombrePais(cliente[7]);
                    var ocliente = new Cliente(cliente[0], cliente[1], cliente[2], cliente[3], cliente[4], cliente[5], cliente[6], cliente[7], nomPais);                   
                    self.arrayClientes.push(ocliente);               
                  });
          });
    });
  }
  
  getClientes() {
      return this.arrayClientes;
  }
  
  getPaises() {
      return this.arrayPaises;
  }
  
  getNombrePais(id) {
      // Se recorre el array de países y se devuelve el nombre cuando el id coincide
      for (var i = 0; i < this.arrayPaises.length; i++) { 
        if (this.arrayPaises[i].id == id) 
          return this.arrayPaises[i].Nombre;
      }
      return "";
  }

  /////////////////////////////////////////////////////////////////////
  // LOS SIGUIENTES MÉTODOS SE CAMBIAN EN EL SIGUIENTE EJERCICIO
  /////////////////////////////////////////////////////////////////////
  
  insertar(cliente) {
      var self = this;
      var datos = JSON.stringify(cliente);
      fetch("./PostBackend/api.php/clientes/",  {
        method: 'POST',
        body: datos,
        headers: {
          "Content-type":"application/x-www-form-urlencoded"
        },
      })
      .then((response) => response.text())
      .then((text) => {
            cliente.id = text;  // Se asume que la BD devuelve el id
            self.arrayClientes.push(cliente);
      });
  }

  modificar(nCliente, DatosModificados) {
      const datos = JSON.stringify(DatosModificados);
      fetch("./PostBackend/api.php/clientes/" + DatosModificados.id + "&order=update",  {
        method: 'PUT',
        body: datos,
        headers: {
          "Content-type":"application/x-www-form-urlencoded"
        },  
      })
      .then((response) => response.text())
      .then((text) => {
          console.log("Respuesta de update:", text);
          // Actualizar el array local (ejemplo, asumiendo que los getters de DatosModificados existen)
          this.arrayClientes[nCliente].genero = DatosModificados.getTitle();
          this.arrayClientes[nCliente].fname = DatosModificados.getFirstName();
          this.arrayClientes[nCliente].lname = DatosModificados.getLastName();
          this.arrayClientes[nCliente].email = DatosModificados.getEmail();
          this.arrayClientes[nCliente].phone = DatosModificados.getPhone();
          this.arrayClientes[nCliente].password = DatosModificados.getPassword();
          this.arrayClientes[nCliente].id_pais = DatosModificados.getId_pais();     
          this.arrayClientes[nCliente].pais = DatosModificados.get_pais();
      });
  }

  // Método existente: elimina un cliente dado su índice
  eliminar(idcliente) {
      var idBD = this.arrayClientes[idcliente].id;
      var self = this;
      fetch("./PostBackend/api.php/clientes/" + idBD,  {
        method: 'DELETE',
        headers: {
          "Content-type":"application/x-www-form-urlencoded"
        },
      })
      .then((response) => response.text())
      .then((text) => {       
        console.log("Mensaje al eliminar: " + text);
        self.arrayClientes.splice(idcliente, 1);
      });
  }

  // NUEVO MÉTODO: eliminarPorCriterio
  eliminarPorCriterio(criterio, valor) {
      var self = this;
      // Recorremos el array desde el final para evitar problemas de índice
      for (let i = self.arrayClientes.length - 1; i >= 0; i--) {
          // Convertir ambos valores a minúsculas para comparación case-insensitive
          if (String(self.arrayClientes[i][criterio]).toLowerCase() === String(valor).toLowerCase()) {
              let idBD = self.arrayClientes[i].id;
              fetch("./PostBackend/api.php/clientes/" + idBD, {
                  method: 'DELETE',
                  headers: {
                      "Content-type": "application/x-www-form-urlencoded"
                  }
              })
              .then(response => response.text())
              .then(text => {
                  console.log("Eliminado cliente con id " + idBD + ": " + text);
                  // Eliminar del array
                  self.arrayClientes.splice(i, 1);
              })
              .catch(error => {
                  console.error("Error al eliminar cliente con id " + idBD, error);
              });
          }
      }
  }
}
