import { Cliente } from '../Pojos/PojoClientes.js';
import { DatosVistaClientes } from './mClientes.js';

console.log("cClientes.js cargado"); // Aseguramos que el archivo se carga

var arrayClientes = []; // Referencia al array del modelo de datos
var arrayPaises = []; 
var mDatosClientes = new DatosVistaClientes(arrayClientes, arrayPaises); // Se ejecuta primero

class ctrl_clientes {
    constructor() {
        console.log("Constructor de ctrl_clientes iniciado");
        arrayClientes = mDatosClientes.getClientes(); // Referencia al array del modelo de datos
        arrayPaises = mDatosClientes.getPaises();

        this.elemVisualizado = 0;

        // Vistas:
        this.VistaHorizontal = document.getElementById("Horizontal"); 
        this.VistaVertical   = document.getElementById("Vertical");

        ///////////////////////////////////
        // Vista vertical de Edición
        ///////////////////////////////////
        this.form     = document.getElementById("miForm");
        this.nombre   = document.getElementById("firstname");
        this.lastname = document.getElementById("lastname");
        this.phone    = document.getElementById("phone");
        this.email    = document.getElementById("email");
        this.password = document.getElementById("password");

        // Botones (vista vertical)
        this.botonModificar = document.getElementById("modificaV");
        this.botonInsertar  = document.getElementById("insertaV");
        this.cancel         = document.getElementById("cancel");
        this.atras          = document.getElementById("atras");
        this.adelante       = document.getElementById("adelante");

        // Eventos (vista vertical)
        this.botonInsertar.addEventListener("click", this.Insertar.bind(this), false);
        this.cancel.addEventListener("click", this.cancelar.bind(this), false);
        this.atras.addEventListener("click", this.Atras.bind(this), false);
        this.adelante.addEventListener("click", this.Adelante.bind(this), false);

        // Validaciones
        this.nombre.addEventListener('blur', this.validaNombre.bind(this), false);
        this.lastname.addEventListener('blur', this.validaApellido.bind(this), false);
        this.phone.addEventListener('blur', this.validaTel.bind(this), false);
        this.password.addEventListener('blur', this.validaPasscode.bind(this), false);
        this.email.addEventListener('blur', this.validaEmail.bind(this), false);

        ////////////////////////////////
        // Vista horizontal (Tabla)
        ////////////////////////////////
        this.inserta = document.getElementById("inserta");
        this.botonModificar = document.getElementById("modificarH") || this.botonModificar;

        this.botonModificar.addEventListener("click", this.ModificarDatos.bind(this), false);
        this.inserta.addEventListener("click", this.CargarParaInsertar.bind(this), false);

        // ----------------------------
        // NUEVA FUNCIÓN: ELIMINAR POR CRITERIO (con input manual)
        // ----------------------------
        this.criterioSelect = document.getElementById("criterioSelect");
        this.valorInput = document.getElementById("valorInput");
        this.btnEliminarCriterio = document.getElementById("btnEliminarCriterio");
        console.log("btnEliminarCriterio en constructor:", this.btnEliminarCriterio);

        if (!this.btnEliminarCriterio) {
          console.error("No se encontró el elemento btnEliminarCriterio. Verifica el ID en el HTML.");
        } else {
          this.btnEliminarCriterio.addEventListener("click", this.eliminarPorCriterio.bind(this), false);
          console.log("Listener asignado a btnEliminarCriterio.");
        }

        // Mostrar tabla al cargar (modo asíncrono)
        setTimeout(() => this.Refres(), 1000);
    }

    eliminarPorCriterio() {
        console.log("Se ejecuta eliminarPorCriterio()");
        const criterio = this.criterioSelect.value;  // ej. "fname"
        const valor = this.valorInput.value.trim();    // valor ingresado

        console.log("Eliminar por criterio:", criterio, "con valor:", valor);
        if (!valor) {
            alert("Debes introducir un valor para filtrar.");
            return;
        }

        let eliminado = false;
        for (let i = arrayClientes.length - 1; i >= 0; i--) {
            // Comparación en minúsculas para que sea case-insensitive
            if (String(arrayClientes[i][criterio]).toLowerCase() === valor.toLowerCase()) {
                console.log("Eliminando cliente en índice", i, "con", criterio, "=", arrayClientes[i][criterio]);
                this.Eliminar(i);
                eliminado = true;
            }
        }
        if (!eliminado) {
            console.log("No se encontró ningún cliente con", criterio, "=", valor);
            alert("No se encontró ningún cliente con ese valor.");
        }
        setTimeout(() => this.Refres(), 1000);
    }

    Refres() {
      this.CargarPaises(); 
      this.GenerarTabla();
      this.ActivaHorizontal();
    }

    CargarParaModificar(index) {
        this.elem = arrayClientes[index];
        this.elemVisualizado = index;
        this.setValues(this.elem);
    }

    ModificarDatos() {
        this.elem = this.getValues();
        mDatosClientes.modificar(this.elemVisualizado, this.elem);
        setTimeout(() => this.Refres(), 1000);
    }

    CargarParaInsertar() {
        this.elem = new Cliente(0, "mr", "", "", "", "", "", "", "");
        this.setValues(this.elem);
        this.ActivaVertical(1);
    }

    Insertar() {
        this.elem = this.getValues();
        mDatosClientes.insertar(this.elem);
        this.elemVisualizado = arrayClientes.length - 1;
        setTimeout(() => this.Refres(), 1000);
    }

    cancelar() {
      this.GenerarTabla();
      this.ActivaHorizontal();
    }

    Eliminar(index) {
        mDatosClientes.eliminar(index);
        this.elemVisualizado = 0;
    }

    GenerarTabla() {
        const tablaClientes = document.getElementById("Tabla");
        tablaClientes.innerHTML = '';

        let table = '<table><tr><th>id</th><th>Nombre</th><th>Apellido</th><th>Email</th><th>Teléfono</th><th>País</th><th>Acciones</th></tr>';

        arrayClientes.forEach((cliente, index) => {
            table += `<tr>
                        <td>${cliente.id}</td>
                        <td>${cliente.fname}</td>
                        <td>${cliente.lname}</td>
                        <td>${cliente.email}</td>
                        <td>${cliente.phone}</td>
                        <td>${cliente.pais}</td>
                        <td>
                            <button class="modificar-btn" data-id="${index}">Modificar</button>
                            <button class="eliminar-btn" data-id="${index}">Eliminar</button>
                        </td>
                      </tr>`;
        });

        table += '</table>';
        tablaClientes.innerHTML = table;

        const botonesModificar = document.querySelectorAll('.modificar-btn');
        const botonesEliminar  = document.querySelectorAll('.eliminar-btn');

        botonesModificar.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.ActivaVertical(0);
                const index = e.target.getAttribute('data-id');
                this.CargarParaModificar(index);
            });
        });

        botonesEliminar.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = e.target.getAttribute('data-id');
                this.Eliminar(index);
                this.GenerarTabla();
            });
        });
    }

    CargarPaises() {
        const select = document.querySelector('#country');
        if (!select) return;
        select.innerHTML = '';

        arrayPaises.forEach((pais, index) => {
            const option = document.createElement('option');
            option.text = pais.Nombre;
            option.value = pais.id;
            select.appendChild(option);
        });
    }

    Atras() {
        if (this.elemVisualizado > 0) {
            this.elemVisualizado--;
            this.show();
        }
    }

    Adelante() {
        if (this.elemVisualizado < arrayClientes.length - 1) {
            this.elemVisualizado++;
            this.show();
        }
    }

    show() {
      var cliente = arrayClientes[this.elemVisualizado];
      this.setValues(cliente);
    }

    getValues() {
        let idBD = document.getElementById("id_cliente").value;
        let title = document.querySelector('input[name="abrev"]:checked')?.value;
        let firstname = document.getElementById("firstname").value;
        let lastname = document.getElementById("lastname").value;
        let email = document.getElementById("email").value;
        let phone = document.getElementById("phone").value;
        let password = document.getElementById("password").value;
        let id_pais = document.getElementById("country").value;
        let pais = mDatosClientes.getNombrePais(id_pais);

        return new Cliente(idBD, title, firstname, lastname, email, phone, password, id_pais, pais);
    }

    setValues(cliente) {
        document.getElementById("id_cliente").value = cliente.id;
        const radio = document.querySelector(`input[name="abrev"][value="${cliente.genero}"]`);
        if (radio) radio.checked = true;
        document.getElementById("firstname").value = cliente.fname;
        document.getElementById("lastname").value = cliente.lname;
        document.getElementById("email").value = cliente.email;
        document.getElementById("phone").value = cliente.phone;
        document.getElementById("password").value = cliente.password;

        const $select = document.querySelector('#country');
        if ($select) $select.value = cliente.id_pais;
    }

    vaciar() {
        document.getElementById("id_cliente").value = 0;
        document.getElementsByName("title").value = "";
        document.getElementById("firstname").value = "";
        document.getElementById("lastname").value = "";
        document.getElementById("email").value = "";
        document.getElementById("phone").value = "";
        document.getElementById("password").value = "";
        document.getElementById("country").value = "";
    }

    ActivaVertical(op) {
        this.VistaHorizontal.style.display = 'none';
        this.VistaVertical.style.display = 'block';
        if (op == 1) {
          this.botonModificar.style.display = 'none'; 
          this.botonInsertar.style.display = 'block'; 
        } else {
          this.botonModificar.style.display = 'block';
          this.botonInsertar.style.display = 'none';
        }
    }

    ActivaHorizontal() {
        this.VistaHorizontal.style.display = 'block';
        this.VistaVertical.style.display = 'none';
    }

    ValidaExpr(campo, pattern, msj) {
        var ref = document.getElementById(campo);
        var camp = ref.value;
        const Exp = new RegExp(pattern);

        if (Exp.test(camp)) {
          ref.setCustomValidity("");
          this.error(ref, "");
        } else {
          ref.setCustomValidity(msj);
          this.error(ref, msj);
          ref.focus();
          this.form.reportValidity();
        }
    }

    validaNombre() {
        this.ValidaExpr("firstname", "[A-Za-z]{5}", "El nombre debe tener al menos 5 letras (solo texto)");
    }

    validaTel() {
        this.ValidaExpr("phone", "^[0-9]{9}$", "El teléfono debe tener 9 dígitos");
    }

    validaApellido(event) {
        if (document.getElementById('lastname').value.length < 2) {
          oCtrlClientes.error(document.getElementById('lastname'), "La longitud debe ser >2 letras");
          return false;
        }
        return true;
    }

    validaEmail() {
        this.ValidaExpr("email", "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$", "formato email incorrecto");
    }

    validaPasscode() {
        this.ValidaExpr("password", "", "");
    }

    error(elemento, mensaje) {
        document.getElementById("mensajeError").innerHTML = mensaje;
        elemento.className = "error";
    }
}

var oCtrlClientes = new ctrl_clientes();
