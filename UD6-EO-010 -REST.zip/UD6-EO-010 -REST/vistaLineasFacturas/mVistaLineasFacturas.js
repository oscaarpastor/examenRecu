import { LineaFactura } from "../Pojos/PojoLineasFacturas.js";

export class DatosVistaLineasFacturas {
    constructor() {
        console.log("Cargando líneas de factura...");
        this.arrayLineasFacturas = [];
        this.cargarLineasFacturas();
    }

    getLineasFacturas() {
        return this.arrayLineasFacturas;
    }

    async cargarLineasFacturas() {
        try {
            const response = await fetch("./PostBackend/api.php/LineasFacturas", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await response.json();
            
            this.arrayLineasFacturas = data.LineasFacturas.records.map(linea =>
                new LineaFactura(linea[0], linea[1], linea[2], linea[3], linea[4], linea[5], linea[6])
            );
        } catch (error) {
            console.error("Error al cargar líneas de factura:", error);
        }
    }

    async agregarLineaFactura(nuevaLinea) {
        try {
            const response = await fetch("./PostBackend/api.php/LineasFacturas", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(nuevaLinea)
            });
            if (response.ok) {
                this.arrayLineasFacturas.push(nuevaLinea);
            }
        } catch (error) {
            console.error("Error al agregar línea de factura:", error);
        }
    }

    async eliminarLineaFactura(id) {
        try {
            const response = await fetch(`./PostBackend/api.php/LineasFacturas/${id}`, {
                method: "DELETE"
            });
            if (response.ok) {
                this.arrayLineasFacturas = this.arrayLineasFacturas.filter(linea => linea.id !== id);
            }
        } catch (error) {
            console.error("Error al eliminar línea de factura:", error);
        }
    }
}
